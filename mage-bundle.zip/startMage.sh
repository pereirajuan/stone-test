#!/bin/sh
cd ./client
./startClient.sh
cd ../server
./startServer.sh